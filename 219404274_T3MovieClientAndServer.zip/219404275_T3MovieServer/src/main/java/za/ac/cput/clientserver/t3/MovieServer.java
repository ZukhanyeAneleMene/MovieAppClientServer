
package za.ac.cput.clientserver.t3;

/**
 *
 * @author 219404275 Zukhanye Anele Mene
 */

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import za.ac.cput.clientserver.t3.Movie;

    public class MovieServer {
        
    private static ArrayList<Movie> movieRecords = new ArrayList<>();
    private static ObjectOutputStream out;
    private static ObjectInputStream in;
    private static ServerSocket serverSocket;
    private static Socket clientSocket;
    private static Object receivedObject;

  
public MovieServer(){

    
        try
        {
            
            
            serverSocket = new ServerSocket(8001, 10);
            
            System.out.println("Server is listening, waiting for connection." );
             clientSocket = serverSocket.accept();  
             System.out.println("Server Started ");
             System.out.println(clientSocket.getInetAddress().getHostAddress()+ " Client connected");
             //getStreams();
             //processClient();
        }
        catch (IOException ioe)
        {
            System.out.println("IOException: " + ioe.getMessage());
        }
}


public void getStreams(){
   
        try {
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            out.flush();
            
            in = new ObjectInputStream(clientSocket.getInputStream());
        } 
        catch (IOException ex) {
            System.out.println("IOException: " + ex.getMessage());
        }
}


   public void processClient() {
          

       while(true){ 
        try {
            
            receivedObject = in.readObject();
            
            
            if (receivedObject instanceof Movie ) {
                
                
                Movie newMovie = (Movie) receivedObject;
              
                System.out.println("Added new movie record" + newMovie);
                movieRecords.add(newMovie);
            }
            else if(receivedObject instanceof String &&((String) receivedObject).equalsIgnoreCase("retrieve")){
              System.out.println( "retrieving");        
              ArrayList lstMovie = (ArrayList)movieRecords.clone(); 
              out.writeObject(lstMovie);
              out.flush(); 
              System.out.println("movie list sent to client" + movieRecords);
            }
            else if(receivedObject instanceof String && ((String) receivedObject).equalsIgnoreCase("exit")){
                     closeConnection();
              
            }
            else {
                    
                     ArrayList<Movie> results = searchMovies ((String)receivedObject);
                     out.writeObject(results);
                     out.flush();
                     
    
            }
         } catch (IOException ex) {
                 System.out.println(" IOException" + ex.getMessage());
             }
           catch (ClassNotFoundException cfe) {
                 cfe.printStackTrace();
             }
            }
         }
   
   private static ArrayList<Movie> searchMovies(String search){

  ArrayList<Movie> results = new ArrayList<>();

  for(Movie movie: movieRecords){

    if(movie.getMovieGenre().toLowerCase().contains(search.toLowerCase())){

      results.add(movie);

    }

  }

  return results;

}

   
    private static void closeConnection() throws IOException{
            
            out.writeObject("exit");
            out.flush();
            in.close();
            out.close();
            clientSocket.close();
            System.out.println("Server closing connection");
            System.exit(0);
         
    }
    
    public static void main(String[] args) {
    
        MovieServer server = new MovieServer();
        server.getStreams();
        server.processClient();
    }
        } 
